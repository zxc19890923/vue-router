<template>
  <div id="me">
    {{msg}}
  </div>
</template>

<script>
export default {
  name: 'me',
  data () {
    return {
      msg: 'me'
    }
  }
}
</script>

