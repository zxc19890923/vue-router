<template>
  <div id="home">
    {{msg}}
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      msg: 'home'
    }
  }
}
</script>

